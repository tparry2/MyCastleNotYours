Usage Instructions:
On the title screen:
	Press 'High Score' button to view the high score
	Press 'Exit' button to exit the app
	Press 'Start' button to move on to game play

On the game play screen:
	Press the bow to fire an arrow at stick figures
	Press the 'Game Over' button to see what will happen when your castle's health is
	fully depleted
		Note: This button will not be in the final release, but aids in showing the
		end game scenario without implementing the stick figure animation

Known Bugs:
none

Areas for Feedback:
How to animate a stick figure along a straight path
How to rotate the bow and use that angle for launching an arrow